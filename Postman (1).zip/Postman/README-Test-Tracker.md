# API Test Progress Tracker

**AgentPortal-API-Test-Progress-Tracker.xlsx** – Use this workbook to track testing progress for all Agent Portal Postman API requests.

## Columns

| Column        | Description |
|---------------|-------------|
| No.           | Row number |
| Collection    | Postman collection name |
| Folder        | Folder path within the collection |
| Request Name  | Name of the request |
| Method        | HTTP method (GET, POST, etc.) |
| URL           | Request URL (with variables like `{{baseUrl}}`) |
| **Status**    | **Not Started** \| **In Progress** \| **Pass** \| **Fail** |
| Tested By     | Tester name |
| Date Tested   | When the test was run (use yyyy-mm-dd) |
| Notes         | Any comments or issues |

## Regenerating the tracker

If you add or remove requests in the Postman collections, regenerate the Excel from the Agent Portal ClientApp folder:

```bash
cd path\to\NewEra.Shell.Web\CLientApp
node scripts/postman-test-tracker.js "C:\Uniquode\AgentPortalPostmanCollection\Postman"
```

The script reads all `*.postman_collection.json` files in the Postman folder and overwrites `AgentPortal-API-Test-Progress-Tracker.xlsx`. **Save your progress (Status, Tested By, Date, Notes) elsewhere before regenerating**, then copy it back or merge manually.
